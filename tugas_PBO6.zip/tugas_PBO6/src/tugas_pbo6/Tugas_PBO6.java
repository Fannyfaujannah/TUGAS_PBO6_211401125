/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tugas_pbo6;

/**
 *
 * @author HP
 */
// Interface suara Hewan
interface AnimalSound {
    void makeSound();
}

//Kelas Abstrak Hewan
abstract class Animal {
    protected String name;
    
    public Animal(String name){
        this.name = name;
    }
    public abstract void display();
    
//Kelas Inner untuk suara Hewan
    class AnimalSoundImpl implements AnimalSound {
        private String sound;
        
        public AnimalSoundImpl(String sound) {
            this.sound = sound;
        }

        @Override
        public void makeSound() {
            System.out.println(name + " makes sound: " + sound);
        }
    }
}
//Implementasi kelas Hewan
class Lion extends Animal {
    public Lion(String name){
        super(name);
    }
    
    @Override
    public void display() {
        System.out.println("Lion : " + name);
    }
}

class Wolf extends Animal {
    public Wolf(String name){
        super(name);
    }

    @Override
    public void display() {
       System.out.println("Wolf : " + name);
    }
}

public class Tugas_PBO6 {
    public static void main(String[] args) {
       // Membuat Objek Hewan dan Suara Hewan 
       Animal lion = new Lion("JACK");
       AnimalSound lionSound = lion.new AnimalSoundImpl("RAWRR!!!!");
       
       Animal wolf = new Wolf("HILDWULF");
       AnimalSound wolfSound = wolf.new AnimalSoundImpl("AUOWWWWWW!!!!");
       
       // Menampilkan informasi hewan dan membuat suara hewan
       lion.display();
       lionSound.makeSound();
       
       wolf.display();
       wolfSound.makeSound();
    }
}
